# SEUBOT — WPPConnect Connector (Multi-tenant)

Conector real do WhatsApp para a plataforma **SEUBOT**, usando **WPPConnect**, com **múltiplas sessões** (um QR por usuário/cliente), persistência de tokens e endpoints simples para integrar no Base44.

## 🧩 Recursos
- Multi-sessão: `sessionId` por cliente
- QR Code real (reconhecido pelo WhatsApp)
- Envio de texto, arquivos, botões
- Persistência de sessão (diretório `./sessions`)
- Pronto para Render/Railway/VPS

## 🚀 Deploy rápido no Render
1. Crie um repositório no GitHub com estes arquivos.
2. Em https://render.com → **New** → **Web Service**.
3. **Build Command**: `npm install`
4. **Start Command**: `node server.js`
5. Opcional: configure `BASE_URL`, `PORT` e `PERSIST_DIR` em **Environment**.

## 🔌 Endpoints
- `POST /sessions/:sessionId/start` → inicia sessão e retorna `{ sessionId, status, qr? }`
- `GET  /sessions/:sessionId/status` → retorna `{ sessionId, status }`
- `DELETE /sessions/:sessionId` → encerra sessão (use `?wipe=true` para limpar tokens)
- `POST /messages/text` → `{ sessionId, number, message }`
- `POST /messages/file` → `{ sessionId, number, fileUrl, caption? }`
- `POST /messages/buttons` → `{ sessionId, number, title, buttons, description? }`

## 🧪 Teste local
```bash
npm install
node server.js
# Em outra janela:
curl -X POST http://localhost:3000/sessions/teste/start
```

## ⚠️ Observações
- Em hosts com filesystem efêmero, prefira um volume persistente ou armazene tokens em um bucket/Redis.
- Para milhares de usuários, use um balanceador e horizontalize instâncias, particionando `sessionId` por nó e mantendo um storage compartilhado (Redis/bucket).
